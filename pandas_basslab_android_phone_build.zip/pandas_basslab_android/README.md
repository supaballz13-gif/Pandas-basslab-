# Panda's BassLab — phone-friendly Android build project

This project includes the branded HTML prototype and a GitHub Actions workflow that builds a debug APK in the cloud. You do not need to install Android Studio on your phone.

## First: run the prototype now
Open `www/index.html` from a file manager after extracting the ZIP, or use the standalone HTML file provided in this chat. Some browser features, especially microphone access, may not work when opened as a local file.

## Build an APK using only your Android phone
You need a free GitHub account and a browser. GitHub's interface can change, so labels may vary slightly.

1. Download and extract this ZIP using your Android file manager (for example, Files by Google).
2. In your phone browser, sign in to GitHub and create a **new private repository** named `pandas-basslab`. Do not initialize it with a README or license.
3. Open the repository, choose **Add file → Upload files**, and upload the project files and folders from the extracted `pandas_basslab_android` folder. Make sure the `.github/workflows/build-apk.yml` file is included. Some mobile upload interfaces hide dot-folders; if so, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the contents from this file.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. If GitHub asks to enable Actions, enable it for the repository.
6. Select **Build Panda's BassLab APK** and tap **Run workflow** if it has not already started automatically.
7. Open the running workflow. Wait until it finishes successfully.
8. Open the completed run and find **Artifacts**. Download `pandas-basslab-debug-apk`. GitHub may download it as a ZIP; extract that ZIP to get `app-debug.apk`.
9. Tap `app-debug.apk` to install. Android may ask you to allow your browser or file manager to install unknown apps. Only allow this for the app you trust, and turn the permission off again afterward if desired.

## Notes
- This produces a **debug/test APK**, not a Play Store-ready release.
- A successful cloud build is not guaranteed until tested; if the build fails, open the failed step and use its error text to troubleshoot.
- The microphone analyzer needs microphone permission and a secure context supported by the Android WebView; test on the actual phone.
- The app uses the phone microphone for acoustic analysis only. It does not measure amplifier voltage or electrically detect clipping.
- Keep audio tests short and quiet at first, and only run them while parked.
- For Play Store publication, you will need a signed release build, privacy policy, and Google Play Console setup.
